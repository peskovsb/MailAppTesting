﻿<?
//-- params
$formId = 'invForm';
$prefix = 'inv';
$formBuild = $prefix.'_'.$formId;

$formArr = array(
	'company_id' =>
		array(
			'name' => $prefix.'_company_id',
			'title' => 'Компания'
		),
	'devtype_id' =>
		array(
			'name' => $prefix.'_devtype_id',
			'title' => 'Тип устройства'
		),
	'device_status' =>
		array(
			'name' => $prefix.'_device_status',
			'title' => 'Статус устройства'
		)
);
?>