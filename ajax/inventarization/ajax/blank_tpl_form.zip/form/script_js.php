﻿<script type="text/javascript">
<?
//-- here goes script
?>
</script>
