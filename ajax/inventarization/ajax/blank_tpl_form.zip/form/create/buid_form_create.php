<?
//-- MAIN REQUIRE FILES
require '../../../../db.php';   //-- DataBase
require '../formArr.php';       //-- Fields Array

//-- Logics Part
require '../controller.php';

//-- View TPL
require 'view_tpl.php';
require '../script_js.php';
?>